package assn07;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class PasswordManager<K, V> implements Map<K, V> {
    private static final String MASTER_PASSWORD = "pass";
    private Account<K, V>[] _passwords;

    public PasswordManager() {
        _passwords = new Account[50];
    }

    @Override
    public void put(K key, V value) {
        int index = getIndex(key);
        Account<K, V> newAccount = new Account<>(key, value);
        Account<K, V> current = _passwords[index];

        if (current == null) {
            _passwords[index] = newAccount;
        } else {
            Account<K, V> prev = null;
            while (current != null) {
                if (current.getWebsite().equals(key)) {
                    current.setPassword(value);
                    return;
                }
                prev = current;
                current = current.getNext();
            }
            prev.setNext(newAccount);
        }
    }

    @Override
    public V get(K key) {
        int index = getIndex(key);
        Account<K, V> current = _passwords[index];
        while (current != null) {
            if (current.getWebsite().equals(key)) {
                return current.getPassword();
            }
            current = current.getNext();
        }
        return null;
    }

    @Override
    public int size() {
        int size = 0;
        for (Account<K, V> account : _passwords) {
            while (account != null) {
                size++;
                account = account.getNext();
            }
        }
        return size;
    }

    @Override
    public Set<K> keySet() {
        Set<K> keys = new HashSet<>();
        for (Account<K, V> account : _passwords) {
            while (account != null) {
                keys.add(account.getWebsite());
                account = account.getNext();
            }
        }
        return keys;
    }

    @Override
    public V remove(K key) {
        int index = getIndex(key);
        Account<K, V> current = _passwords[index];
        Account<K, V> prev = null;

        while (current != null) {
            if (current.getWebsite().equals(key)) {
                if (prev == null) {
                    _passwords[index] = current.getNext();
                } else {
                    prev.setNext(current.getNext());
                }
                return current.getPassword();
            }
            prev = current;
            current = current.getNext();
        }
        return null;
    }

    @Override
    public List<K> checkDuplicate(V value) {
        List<K> duplicates = new ArrayList<>();
        for (Account<K, V> account : _passwords) {
            while (account != null) {
                if (account.getPassword().equals(value)) {
                    duplicates.add(account.getWebsite());
                }
                account = account.getNext();
            }
        }
        return duplicates;
    }

    @Override
    public boolean checkMasterPassword(String enteredPassword) {
        return MASTER_PASSWORD.equals(enteredPassword);
    }

    @Override
    public String generatesafeRandomPassword(int length) {
        length = Math.max(length, 4);
        int leftLimit = 48;
        int rightLimit = 122;
        Random random = new Random();

        String generatedString = random.ints(leftLimit, rightLimit + 1)
                .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
                .limit(length)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();

        return generatedString;
    }

    private int getIndex(K key) {
        int hashCode = Math.abs(key.hashCode());
        return hashCode % _passwords.length;
    }

    public Account<K, V>[] getPasswords() {
        return _passwords;
    }
}
