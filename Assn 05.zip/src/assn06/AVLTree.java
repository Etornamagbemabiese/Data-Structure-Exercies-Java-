package assn06;

public class AVLTree<T extends Comparable<T>> implements SelfBalancingBST<T> {
    private T _value;
    private AVLTree<T> _left;
    private AVLTree<T> _right;
    private int _height;
    private int _size;

    public AVLTree() {
        _value = null;
        _left = null;
        _right = null;
        _height = -1;
        _size = 0;
    }

    private AVLTree<T> rotateLeft() {
        AVLTree<T> newRoot = _right;
        _right = newRoot._left;
        newRoot._left = this;
        updateHeightAndSize();
        newRoot.updateHeightAndSize();
        return newRoot;
    }

    private AVLTree<T> rotateRight() {
        AVLTree<T> newRoot = _left;
        _left = newRoot._right;
        newRoot._right = this;
        updateHeightAndSize();
        newRoot.updateHeightAndSize();
        return newRoot;
    }
    private void updateHeightAndSize() {
        int leftHeight = (_left == null) ? -1 : _left._height;
        int rightHeight = (_right == null) ? -1 : _right._height;
        _height = 1 + Math.max(leftHeight, rightHeight);
        _size = 1 + (_left == null ? 0 : _left.size()) + (_right == null ? 0 : _right.size());
    }

    private AVLTree<T> rebalance() {
        updateHeightAndSize();
        int balanceFactor = getBalanceFactor();

        if (balanceFactor > 1) {
            if (_left.getBalanceFactor() < 0) {
                _left = _left.rotateLeft();
            }
            return rotateRight();
        } else if (balanceFactor < -1) {
            if (_right.getBalanceFactor() > 0) {
                _right = _right.rotateRight();
            }
            return rotateLeft();
        }

        return this;
    }

    private int getBalanceFactor() {
        int leftHeight = (_left == null) ? -1 : _left._height;
        int rightHeight = (_right == null) ? -1 : _right._height;
        return leftHeight - rightHeight;
    }
    @Override
    public boolean isEmpty() {
        return size() == 0;
    }

    @Override
    public int height() {
        return _height;
    }

    @Override
    public int size() {
        return _size;
    }

    @Override
    public SelfBalancingBST<T> insert(T element) {
        if (isEmpty()) {
            _value = element;
            _left = new AVLTree<>();
            _right = new AVLTree<>();
            updateHeightAndSize();
            return this;
        }

        int c = element.compareTo(_value);
        if (c < 0) {
            _left = (AVLTree<T>) _left.insert(element);
        } else if (c > 0) {
            _right = (AVLTree<T>) _right.insert(element);
        }
        return rebalance();
    }

    @Override
    public SelfBalancingBST<T> remove(T element) {
        if (isEmpty()) {
            return this;
        }

        int c = element.compareTo(_value);
        if (c < 0) {
            _left = (AVLTree<T>) _left.remove(element);
        } else if (c > 0) {
            _right = (AVLTree<T>) _right.remove(element);
        } else {
            if (_left.isEmpty() && _right.isEmpty()) {
                return new AVLTree<>();
            } else if (_left.isEmpty()) {
                return _right;
            } else if (_right.isEmpty()) {
                return _left;
            } else {
                AVLTree<T> minRight = _right;
                while (!minRight._left.isEmpty()) {
                    minRight = minRight._left;
                }
                _value = minRight._value;
                _right = (AVLTree<T>) _right.remove(minRight._value);
            }
        }
        return rebalance();
    }

    @Override
    public T findMin() {
        if (isEmpty()) {
            throw new RuntimeException("Illegal operation on empty tree");
        }
        if (_left.isEmpty()) {
            return _value;
        }
        return _left.findMin();
    }

    @Override
    public T findMax() {
        if (isEmpty()) {
            throw new RuntimeException("Illegal operation on empty tree");
        }
        if (_right.isEmpty()) {
            return _value;
        }
        return _right.findMax();
    }

    @Override
    public boolean contains(T element) {
        if (isEmpty()) {
            return false;
        }
        int c = element.compareTo(_value);
        if (c < 0) {
            return _left.contains(element);
        } else if (c > 0) {
            return _right.contains(element);
        } else {
            return true;
        }
    }

    @Override
    public boolean rangeContain(T start, T end) {
        if (isEmpty()) {
            return false;
        }
        int cStart = start.compareTo(_value);
        int cEnd = end.compareTo(_value);
        if (cStart <= 0 && cEnd >= 0) {
            return true;
        }
        if (cStart < 0 && !_left.isEmpty()) {
            return _left.rangeContain(start, end);
        }
        if (cEnd > 0 && !_right.isEmpty()) {
            return _right.rangeContain(start, end);
        }
        return false;
    }

    @Override
    public T getValue() {
        return _value;
    }

    @Override
    public SelfBalancingBST<T> getLeft() {
        if (isEmpty()) {
            return null;
        }
        return _left;
    }

    @Override
    public SelfBalancingBST<T> getRight() {
        if (isEmpty()) {
            return null;
        }
        return _right;
    }


}
